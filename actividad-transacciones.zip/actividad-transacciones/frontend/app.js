const API_URL = 'http://localhost:3000';

async function obtenerProductos() {
  try {
    const res = await fetch(`${API_URL}/?filtro=productos`);
    const productos = await res.json();

    let html = `
      <table>
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Precio</th>
          <th>Existencias</th>
        </tr>
    `;

    productos.forEach(p => {
      html += `
        <tr>
          <td>${p.id_producto}</td>
          <td>${p.nombre}</td>
          <td>$${p.precio}</td>
          <td>${p.existencias}</td>
        </tr>
      `;
    });

    html += '</table>';
    document.getElementById('tablaProductos').innerHTML = html;
  } catch (error) {
    console.error('Error al obtener productos:', error);
  }
}

document.getElementById('formOrden').addEventListener('submit', async (e) => {
  e.preventDefault();

  const mensajeDiv = document.getElementById('mensajeResultado');
  mensajeDiv.style.display = 'none';

  const rut = document.getElementById('rut').value;
  const id_direccion = parseInt(document.getElementById('idDireccion').value);
  const id_producto = parseInt(document.getElementById('idProducto').value);
  const cantidad = parseInt(document.getElementById('cantidad').value);

  const payload = {
    rut,
    id_direccion,
    productos: [
      { id_producto, cantidad }
    ]
  };

  try {
    const res = await fetch(`${API_URL}/orden`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await res.json();

    mensajeDiv.style.display = 'block';
    if (res.ok) {
      mensajeDiv.className = 'mensaje exito';
      mensajeDiv.innerText = `${data.mensaje} (ID Orden: ${data.orden.id_orden})`;
      obtenerProductos();
    } else {
      mensajeDiv.className = 'mensaje error';
      mensajeDiv.innerText = data.mensaje;
    }
  } catch (error) {
    mensajeDiv.style.display = 'block';
    mensajeDiv.className = 'mensaje error';
    mensajeDiv.innerText = 'Error al conectar con el servidor.';
  }
});

async function consultarOrdenes() {
  const rut = document.getElementById('rutConsulta').value;
  if (!rut) return;

  try {
    const res = await fetch(`${API_URL}/?filtro=ordenes&rut=${rut}`);
    const ordenes = await res.json();

    if (!res.ok) {
      document.getElementById('tablaOrdenes').innerHTML = `<p>${ordenes.error}</p>`;
      return;
    }

    let html = `
      <table>
        <tr>
          <th>ID Orden</th>
          <th>RUT</th>
          <th>Dirección</th>
          <th>Total</th>
        </tr>
    `;

    ordenes.forEach(o => {
      html += `
        <tr>
          <td>${o.id_orden}</td>
          <td>${o.rut}</td>
          <td>${o.direccion}</td>
          <td>$${o.precio_total}</td>
        </tr>
      `;
    });

    html += '</table>';
    document.getElementById('tablaOrdenes').innerHTML = html;
  } catch (error) {
    console.error('Error al consultar órdenes:', error);
  }
  document.addEventListener('DOMContentLoaded', obtenerProductos);
}