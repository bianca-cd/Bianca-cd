const express = require('express');
const cors = require('cors');
const pool = require('./db');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get('/', async (req, res) => {
  const { filtro, id, orden, rut } = req.query;

  try {
    if (filtro === 'productos') {
      if (id) {
        const q = { text: 'SELECT * FROM productos WHERE id_producto = $1', values: [id] };
        const { rows } = await pool.query(q);
        if (rows.length === 0) return res.status(404).json({ error: 'Producto no encontrado' });
        return res.json(rows[0]);
      }

      if (orden) {
        const q = {
          text: `
            SELECT p.id_producto, p.nombre, p.precio, lp.cantidad_producto
            FROM lista_productos lp
            JOIN productos p ON lp.id_producto = p.id_producto
            WHERE lp.id_orden = $1
          `,
          values: [orden]
        };
        const { rows } = await pool.query(q);
        return res.json(rows);
      }

      const { rows } = await pool.query('SELECT * FROM productos ORDER BY id_producto ASC');
      return res.json(rows);
    }

    if (filtro === 'ordenes') {
      if (!rut) return res.status(400).json({ error: 'Se requiere el parámetro rut' });
      const q = {
        text: `
          SELECT o.id_orden, o.rut, o.precio_total, d.direccion
          FROM orden o
          JOIN direcciones d ON o.id_direccion = d.id_direccion
          WHERE o.rut = $1
          ORDER BY o.id_orden DESC
        `,
        values: [rut]
      };
      const { rows } = await pool.query(q);
      return res.json(rows);
    }

    if (filtro === 'clientes') {
      if (rut) {
        const q = { text: 'SELECT * FROM clientes WHERE rut = $1', values: [rut] };
        const { rows } = await pool.query(q);
        if (rows.length === 0) return res.status(404).json({ error: 'Cliente no encontrado' });
        return res.json(rows[0]);
      }
      const { rows } = await pool.query('SELECT * FROM clientes ORDER BY nombre ASC');
      return res.json(rows);
    }

    if (filtro === 'direcciones') {
      if (!rut) return res.status(400).json({ error: 'Se requiere el parámetro rut' });
      const q = { text: 'SELECT * FROM direcciones WHERE rut = $1', values: [rut] };
      const { rows } = await pool.query(q);
      return res.json(rows);
    }

    if (filtro === 'despachos') {
      if (!orden) return res.status(400).json({ error: 'Se requiere el parámetro orden' });
      const q = {
        text: `
          SELECT des.id_despacho, des.id_orden, dir.direccion, cli.nombre AS cliente
          FROM despachos des
          JOIN direcciones dir ON des.id_direccion = dir.id_direccion
          JOIN clientes cli ON dir.rut = cli.rut
          WHERE des.id_orden = $1
        `,
        values: [orden]
      };
      const { rows } = await pool.query(q);
      if (rows.length === 0) return res.status(404).json({ error: 'Despacho no encontrado' });
      return res.json(rows[0]);
    }

    return res.status(400).json({ error: 'Filtro no válido o no especificado.' });

  } catch (error) {
    res.status(500).json({ error: 'Error en la consulta', detalles: error.message });
  }
});

app.post('/orden', async (req, res) => {
  const { rut, id_direccion, productos } = req.body;

  if (!rut || !id_direccion || !productos || !Array.isArray(productos) || productos.length === 0) {
    return res.status(400).json({ ok: false, mensaje: 'Datos de la orden incompletos o inválidos.' });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    let precioTotalOrden = 0;

    for (const item of productos) {
      const resProd = await client.query({
        text: 'SELECT id_producto, nombre, precio, existencias FROM productos WHERE id_producto = $1 FOR UPDATE',
        values: [item.id_producto]
      });

      if (resProd.rows.length === 0) {
        throw new Error(`El producto con ID ${item.id_producto} no existe.`);
      }

      const prod = resProd.rows[0];

      if (prod.existencias < item.cantidad) {
        throw new Error(`Falta de stock: El producto "${prod.nombre}" solo tiene ${prod.existencias} unidades disponibles (solicitadas: ${item.cantidad}).`);
      }

      precioTotalOrden += prod.precio * item.cantidad;
    }

    const qOrden = {
      text: 'INSERT INTO orden (rut, id_direccion, precio_total) VALUES ($1, $2, $3) RETURNING id_orden, rut, id_direccion, precio_total',
      values: [rut, id_direccion, precioTotalOrden]
    };
    const resOrden = await client.query(qOrden);
    const nuevaOrden = resOrden.rows[0];

    const qDespacho = {
      text: 'INSERT INTO despachos (id_orden, id_direccion) VALUES ($1, $2) RETURNING id_despacho',
      values: [nuevaOrden.id_orden, id_direccion]
    };
    await client.query(qDespacho);

    for (const item of productos) {
      await client.query({
        text: 'INSERT INTO lista_productos (id_orden, id_producto, cantidad_producto) VALUES ($1, $2, $3)',
        values: [nuevaOrden.id_orden, item.id_producto, item.cantidad]
      });

      await client.query({
        text: 'UPDATE productos SET existencias = existencias - $1 WHERE id_producto = $2',
        values: [item.cantidad, item.id_producto]
      });
    }

    await client.query('COMMIT');

    return res.status(201).json({
      ok: true,
      mensaje: 'Orden de compra creada exitosamente.',
      orden: nuevaOrden
    });

  } catch (error) {
    await client.query('ROLLBACK');
    return res.status(409).json({
      ok: false,
      mensaje: error.message || 'Error en la transacción. Se realizó ROLLBACK.'
    });

  } finally {
    client.release();
  }
});

app.listen(PORT, () => {
  console.log(`Servidor ejecutándose en puerto ${PORT}`);
});